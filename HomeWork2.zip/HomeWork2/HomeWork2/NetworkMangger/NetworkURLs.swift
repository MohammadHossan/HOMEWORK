//
//  NetworkURLs.swift
//  FirstURLSession
//
//  Created by Christian Quicano on 1/27/22.
//

import Foundation

enum NetworkURLs {
    static let baseURL = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=1000&api_key=aKj0h3ZdldeCmCS0avqYHZb4jTFrjUBB4LnYilTT"
    static let postsURL = "\(baseURL)/posts"
}

