//
//  NetworkManager.swift
//  HomeWork2
//
//  Created by test on 03/02/2022.
//

import Foundation

class NetworkManager{
    
    
    func fetchData(completion: @escaping ([Rover]) -> Void) {
       
        
        if let url = URL(string: "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=1000&api_key=DEMO_KEY") {
            
            URLSession.shared.dataTask(with: url) { data, urlResponse, error in
                
                if let data = data {
                    
                    do {
                        let result = try JSONDecoder().decode([Rover].self, from: data)
                        completion(result)
                    } catch let error {
                        print(error)
                    }
                    
                    
                }
                
            }
            .resume()
        }
        
        
    }
}
